package application;

import javafx.scene.image.Image;

public class keksImage extends IMAGE {
	
	private static Image image = new Image("keks-bild.jpg");
	
	public Image image() {
		return image;
		
	}
	
}
