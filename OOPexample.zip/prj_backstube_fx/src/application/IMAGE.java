package application;

import javafx.scene.image.Image;

public abstract class IMAGE {
	
	public abstract Image image();

}
