package application;

import javafx.scene.image.Image;

public class rolleImage extends IMAGE {
	
	private static Image image = new Image("prinzen-rolle.jpg");
	
	public Image image() {
		return image;
		
	}
	
}
