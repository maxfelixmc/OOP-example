package application;

public class Methoden {
	static Keks[] add(Keks arr[], Keks x) 
	   { 
	       int i; 
	       int y;
	       if (arr == null) {
	    	   y = 0;
	       }
	       else {
	    	   y = arr.length;
	       }
	       Keks newarr[] = new Keks[y + 1]; 
	       for (i = 0; i < y; i++) 
	           newarr[i] = arr[i]; 
	   
	       newarr[y] = x; 
	   
	       return newarr; 
	   } 
	
	static Rolle[] add(Rolle arr[], Rolle x) 
	   { 
	       int i; 
	       int y;
	       if (arr == null) {
	    	   y = 0;
	       }
	       else {
	    	   y = arr.length;
	       }
	       Rolle newarr[] = new Rolle[y + 1]; 
	       for (i = 0; i < y; i++) 
	           newarr[i] = arr[i]; 
	   
	       newarr[y] = x; 
	   
	       return newarr; 
	   } 
}
