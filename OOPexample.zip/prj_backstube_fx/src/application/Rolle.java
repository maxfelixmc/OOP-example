package application;

import java.util.Random;

import javafx.collections.ObservableList;

public class Rolle {
	
	
	Random rand = new Random();
	
	public IMAGE image = new rolleImage();
	
	public Keks[] inhalt ;
	private boolean offen = false;
	
	public String name = "Doppelkekse von maier";
	
	public Rolle() {
		
		for (int i=0; i<22 ; i++) {
			
			inhalt = Methoden.add(inhalt, new Keks());
			
		}
		
	}
	
	public Rolle(ObservableList<Keks> neurolle) {
		
		
		Keks[] uebergabe = null;
		
		for (int i=0; i<neurolle.size() ; i++) {
			
			Keks k = neurolle.get(i);
			
			uebergabe = Methoden.add(uebergabe, new Keks(k.name, k.sorte, k.image));
		}
		
		inhalt = uebergabe;
		
	}
	
	public Keks keksnehmen() {
		
		if (inhalt.length > 0) {
		
			Keks p = inhalt[inhalt.length-1];
			
			Keks[] uebergang = new Keks[inhalt.length-1];
			
			
			for (int i=0; i<uebergang.length;i++) {
				uebergang[i] = inhalt[i];
			}
			inhalt = uebergang;
			
			return p;
		}
		
		return null;
	}
	
	public void offnen() {
		offen = true;
		
		System.out.println("Rolle wurde geöffnet");
	}
	
	public void show() {
		
		if (offen) {
			System.out.println(inhalt.length + "Kekse von 22");
		
			for (Keks i : inhalt) {
				System.out.println("--new-Keks-------");
				i.show();
				}
			}
		else {
			
			System.out.println("Wurde noch nicht geöffnet");
			
		}
		
		
	}
		
	
}
