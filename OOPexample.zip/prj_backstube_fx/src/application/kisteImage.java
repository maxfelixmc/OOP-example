package application;

import javafx.scene.image.Image;

public class kisteImage extends IMAGE {
	
	private static Image image = new Image("vector-package-icon.jpg");
	
	public Image image() {
		return image;
		
	}
	
}
