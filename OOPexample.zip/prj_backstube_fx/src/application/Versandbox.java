package application;

import javafx.collections.ObservableList;

public class Versandbox {
	
	public Rolle[] inhalt;
	
	public IMAGE image = new kisteImage();
	
	public String Packung = "Doppelkekse Maier";
	public String Beschreibung = "Beste doppelkese von maier 16 x22 stück";
	
	public Versandbox() {
		
		for (int i=0; i<16 ; i++) {
			
			inhalt = Methoden.add(inhalt, new Rolle());
			
			
		}
		
	}
	
	public Versandbox(ObservableList<Keks> pNeurolle) {
		
		for (int i=0; i<16 ; i++) {
			
			
			inhalt = Methoden.add(inhalt, new Rolle(pNeurolle));
			
		}
		
	}
	
	public Rolle rollenehmen() {
			
			Rolle p = inhalt[inhalt.length-1];
			
			Rolle[] uebergang = new Rolle[inhalt.length-1];
			
			
			for (int i=0; i<uebergang.length;i++) {
				uebergang[i] = inhalt[i];
			}
			inhalt = uebergang;
			
			return p;
	}
	
	public void show() {
		
		System.out.println(inhalt.length + "Kekse von 16");
		
		for (Rolle i : inhalt) {
			System.out.println("--new-Rolle------");
			i.show();
			}
		}

	public Rolle[] getInhalt() {
		return inhalt;
	}

	public void setInhalt(Rolle[] pInhalt) {
		inhalt = pInhalt;
	}

	public String getPackung() {
		return Packung;
	}

	public void setPackung(String pPackung) {
		Packung = pPackung;
	}

	public String getBeschreibung() {
		return Beschreibung;
	}

	public void setBeschreibung(String pBeschreibung) {
		Beschreibung = pBeschreibung;
	}
	
}
