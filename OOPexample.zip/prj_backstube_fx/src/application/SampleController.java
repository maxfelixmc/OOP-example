package application;

import javafx.scene.input.MouseEvent;
import javafx.scene.image.ImageView;
import java.util.HashMap;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import zutaten.Zutaten;

public class SampleController {
	
	ObservableList<Versandbox> versandboxen = FXCollections.observableArrayList();
	ObservableList<Keks> neurolle = FXCollections.observableArrayList();
	HashMap<String, Keks> kessortiment = new HashMap<String, Keks>();
	
	Rolle rolle;
	Keks keks;
	
    @FXML
    private TableColumn<Versandbox, String> Beschreibungtabelle;

    @FXML
    private TableColumn<Versandbox, String> Pakungtabelle;

    @FXML
    private TextField Rolle_namen;

    @FXML
    private Button Rolle_nehmen;

    @FXML
    private TextArea keks_info;

    @FXML
    private Button keks_nehmen;

    @FXML
    private Button rolle_wegwerfen;

    @FXML
    private TableView<Versandbox> tabelle;
    
//--------------------------------------------------------------

    @FXML
    private Button Keks_hinzufuegn;

    @FXML
    private ComboBox<String> Kekscombobox;

    @FXML
    private Button Kiste_erstellen;

    @FXML
    private Button Layout_loeschen;

    @FXML
    private ImageView Verpackung_bild;

    @FXML
    private TableColumn<Keks, IMAGE> column_erstellen;

    @FXML
    private ImageView keks_bild;

    @FXML
    private ImageView rolle_bild;

    @FXML
    private TableView<Keks> tabellle_erstellen;
//--------------------------------------------------------------
    
    
    @FXML
    public void initialize() {
    	
    	 versandboxen.clear();
     	
    	 versandboxen.add(new Versandbox());
     	 versandboxen.add(new Versandbox());
     	 
     	 kessortiment.put("Doppelkeks", new Keks());
     	 kessortiment.put("keks 2", new Keks("Keks 2", "keks", new kisteImage()));
     	 
     	 Kekscombobox.getItems().addAll("Doppelkeks", "keks 2");
     	 
     	 
     	column_erstellen.setCellFactory(param -> {

            ImageView imageview = new ImageView();
            imageview.setFitHeight(50);
            imageview.setFitWidth(50);

            TableCell<Keks, IMAGE> cell = new TableCell<Keks, IMAGE>() {
                public void updateItem(IMAGE item, boolean empty) {
                  if (item != null && empty != true) {
                       imageview.setImage(item.image());
                  }
                }
             }; 
             cell.setGraphic(imageview);
             return cell;
        });
     	 
     	 
     	 column_erstellen.setCellValueFactory(new PropertyValueFactory<Keks, IMAGE>("image"));
     	 
    	 Pakungtabelle.setCellValueFactory(new PropertyValueFactory<Versandbox, String>("Packung"));
    	 Beschreibungtabelle.setCellValueFactory(new PropertyValueFactory<Versandbox, String>("Beschreibung"));
    	 
    	 tabelle.setItems(versandboxen);
    	 tabellle_erstellen.setItems(neurolle);
    	 
    	 
    	 
    }

    @FXML
    void Knehmen(ActionEvent event) {
    	
    	String namen = "Zutaten:\n\r";
    	
    	
    	keks = rolle.keksnehmen();
    	
    	for (Zutaten i:keks.zutaten) {
    		
    		namen += "	" + i.getname() + "\n\r";
    		
    	}
    	keks_bild.setImage(keks.image.image());
    	keks_info.setText(keks.name +" in Packung : "+ (rolle.inhalt.length)+ "\n\r" + namen);
    	
    }

    @FXML
    void Rnehemn(ActionEvent event) {
    	
    	if (rolle == null) {
    		
    	TablePosition pos = tabelle.getSelectionModel().getSelectedCells().get(0);
    	int row = pos.getRow();
    	System.out.println("box: "+versandboxen);
    	Versandbox item = tabelle.getItems().get(row);
    	System.out.println("item: "+item);
    	System.out.println("item anzahl: "+item.inhalt.length);
    	int uo = item.inhalt.length;
    	
    	if (uo <= 0) {
    		System.out.println(versandboxen);
    		versandboxen.remove(row);
    		System.out.println(versandboxen);
    		System.out.println("gelöscht");
    	}
    	else {
    		if (item != null) {
    			
		    	rolle = item.rollenehmen();
		    	
		    	System.out.println("geladen");
		    	versandboxen.set(row, item);
		    	
		    	System.out.println("item anzahl: "+item.inhalt.length);
		    	rolle_bild.setImage(rolle.image.image());
		    	Rolle_namen.setText(rolle.name);
		    	}
	    	}
    	}
    }

    @FXML
    void Rwegwerfen(ActionEvent event) {
    	rolle = null;
    	rolle_bild.setImage(null);
    	Rolle_namen.setText("");
    }
    

	
	@FXML
	void Kerstellen(ActionEvent event) {
     	
    	versandboxen.add(new Versandbox(neurolle));
		
	}
	
	
	
	
	
	@FXML
	void Layoutdelete(ActionEvent event) {
		
		neurolle.clear();
		
	}




	@FXML
	void setpicture(MouseEvent event) {
		
		TablePosition pos = tabelle.getSelectionModel().getSelectedCells().get(0);
    	int row = pos.getRow();
    	Versandbox item = tabelle.getItems().get(row);
    	
		Verpackung_bild.setImage(item.image.image());
		keks_info.setText("Rollen in Box: " + item.inhalt.length);
		
		
	
	}
	
	@FXML
    void Kadd(ActionEvent event) {
		
		column_erstellen.setCellFactory(param -> {

            ImageView imageview = new ImageView();
            imageview.setFitHeight(50);
            imageview.setFitWidth(50);

            TableCell<Keks, IMAGE> cell = new TableCell<Keks, IMAGE>() {
                public void updateItem(IMAGE item, boolean empty) {
                  if (item != null && empty != true) {
                       imageview.setImage(item.image());
                  }
                }
             }; 
             cell.setGraphic(imageview);
             return cell;
        });
		
		if (neurolle.size() <= 22) {
			Keks keks_1 = kessortiment.get(Kekscombobox.getValue());
			neurolle.add(keks_1);
		}
		else {
			System.out.println("max erreicht");
		}
    }

}
