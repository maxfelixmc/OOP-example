package application;

import zutaten. *;

public class Keks {
	
	public IMAGE image = new keksImage();
	
	int grosseInQuadratcentimeter = 38;
	Zutaten zutaten[] = {new KeksTeig(1, 2),new Schockolade(1, 1) , new KeksTeig(1, 2)};
	String name = "Doppel Kekse";
	String sorte = "Doppel Keks";
	
	public Keks(String name, String sorte, IMAGE image) {
		
		this.name = name;
		this.sorte = sorte;
		this.image = image;
		
	}
	
	public Keks() {
		
	}

	public void show() {
		
		System.out.println("Keks Name: " + name);
		System.out.println("Keks Sorte: " + sorte);
		
		double preis = 0;
		
		for(Zutaten i : zutaten) {
			
			preis += (i.getGewichtPQcentimeter()*(grosseInQuadratcentimeter / 10) * i.getSchichtHoehe()) * i.getPreisProGramm();
			
			
		}
		
		
		System.out.println("Keks Preis: " + preis);
		
	}

	public IMAGE getImage() {
		return image;
	}

	public int getGrosseInQuadratcentimeter() {
		return grosseInQuadratcentimeter;
	}

	public Zutaten[] getZutaten() {
		return zutaten;
	}

	public String getName() {
		return name;
	}

	public String getSorte() {
		return sorte;
	}

	public void setImage(IMAGE pImage) {
		image = pImage;
	}

	public void setGrosseInQuadratcentimeter(int pGrosseInQuadratcentimeter) {
		grosseInQuadratcentimeter = pGrosseInQuadratcentimeter;
	}

	public void setZutaten(Zutaten[] pZutaten) {
		zutaten = pZutaten;
	}

	public void setName(String pName) {
		name = pName;
	}

	public void setSorte(String pSorte) {
		sorte = pSorte;
	}
	
}
