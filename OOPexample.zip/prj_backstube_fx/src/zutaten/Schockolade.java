package zutaten;

public class Schockolade extends Zutaten {
	
	private int grosseInQ = 0;
	private int schichthoehe = 0;
	
	public Schockolade(int grosseInQ, int pI) {
		
		super(2, 0.01495, "vollmilch schockolade");
		this.grosseInQ = grosseInQ;
		this.schichthoehe = pI;
		
	}
	
	public double getGewichtPQcentimeter() {
		return gewichtPQcentimeter;
	}
	
	public double getPreisProGramm() {
		return preisProGramm;
	}
	
	public double getSchichtHoehe() {
		return schichthoehe;
	}
	
}
