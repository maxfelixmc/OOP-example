package zutaten;

public abstract class Zutaten {
	
	protected double gewichtPQcentimeter;
	protected double preisProGramm;
	protected String name;
	
	public Zutaten(double pI, double pD, String h) {
		gewichtPQcentimeter = pI;
		preisProGramm = pD;
		name = h;
	}

	public abstract double getGewichtPQcentimeter();
	public abstract double getPreisProGramm();

	public abstract double getSchichtHoehe();
	
	public  String getname() {
		return name;
	}
		
	
}
