package zutaten;

public class KeksTeig extends Zutaten {
	
	private boolean istGebacken = true;
	private int grosseInQ = 0;
	private int schichthoehe = 0;
	
	public KeksTeig(int grosseInQ, int pI) {
		
		super(1, 0.005, "Mürbeteig");
		this.grosseInQ = grosseInQ;
		this.schichthoehe = pI;
		
	}
	
	
	public boolean backen() {
		
		istGebacken = true;
		return istGebacken;
		
	}

	public double getGewichtPQcentimeter() {
		return gewichtPQcentimeter;
	}
	
	public double getPreisProGramm() {
		return preisProGramm;
	}
	
	public boolean istGebacken() {
		return istGebacken;
	}
	
	public double getSchichtHoehe() {
		return schichthoehe;
	}


	


}
